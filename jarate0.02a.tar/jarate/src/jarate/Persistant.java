package jarate;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

class Persistant implements ActionListener {
	@Override
	public void actionPerformed(ActionEvent e) {
		validate();
	}

	public static boolean amValid() {
		return true;
	}

	public static void validate() {
		if (amValid()) {
			Jar.persistant.setText("Persistant Unlock");
		} else {
			Jar.persistant.setText("Remove persistant lock");
		}
		Jar.persistant.setEnabled(false);
	}
}