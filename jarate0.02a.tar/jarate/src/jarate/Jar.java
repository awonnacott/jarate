package jarate;

import java.awt.Dimension;
import java.io.File;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;

public class Jar {
	static final File guide = new File ("/tmp/ls/lsguide");
	static final Dimension screen = java.awt.Toolkit.getDefaultToolkit().getScreenSize();
	static final Dimension size = new Dimension (200, 160);
	static final JFrame frame1 = new JFrame();
	static final JPanel panel1 = new JPanel();
	static final JLabel label1 = new JLabel("Jarate: Karate in a Jar");
	static final JButton persistant = new JButton();
	static final JButton tempOn = new JButton();
	static final JButton uninstall = new JButton ("Uninstall Jarate");
	static final JButton quit = new JButton ("Quit Jarate");
	
	static void startGraphics() {
		panel1.add (label1);
		Persistant.validate();
		persistant.addActionListener (new jarate.Persistant());
		panel1.add (persistant);
		TempOn.validate();
		tempOn.addActionListener (new jarate.TempOn());
		panel1.add (tempOn);
		Uninstall.validate();
		uninstall.addActionListener (new jarate.Uninstall());
		panel1.add (uninstall);
		quit.addActionListener (new jarate.Quit());
		panel1.add (quit);
		frame1.add (panel1);
		frame1.setResizable (false);
		frame1.setUndecorated (true);
		frame1.setBounds ((screen.width/2)-(size.width/2), (screen.height/2)-(size.height/2), size.width, size.height);
		frame1.setVisible (true);
	}
	
	public static void main(String[] args) {
		if (args.length == 0) {
			startGraphics();
		} else {
			guide.delete();
			System.exit(0);
		}
	}
}
