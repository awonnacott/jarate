package jarate;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

class Uninstall implements ActionListener {
	@Override
	public void actionPerformed(ActionEvent e) {
		validate();
	}

	public static boolean amValid() {
		return false;
	}

	public static void validate() {
		if (amValid()) {
			Jar.uninstall.setEnabled(true);
			Jar.uninstall.setText("Completely Uninstall Jarate");
		} else {
			Jar.uninstall.setEnabled(false);
			Jar.uninstall.setText("No files to uninstall");
		}
	}
}