package jarate;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

class TempOn implements ActionListener {
	@Override
	public void actionPerformed(ActionEvent e) {
		Jar.guide.delete();
		validate();
	}

	public static void validate() {
		if (Jar.guide.exists()) {
			Jar.tempOn.setEnabled(true);
			Jar.tempOn.setText("Temporary Unlock");
		} else {
			Jar.tempOn.setEnabled(false);
			Jar.tempOn.setText("Currently Unlocked");
		}
	}
}
